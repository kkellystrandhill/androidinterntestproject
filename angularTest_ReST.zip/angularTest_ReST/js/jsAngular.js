var angularTestApp = angular.module('angularApp', []);
angularTestApp.controller('angularController', function($http, $scope) {
    
    $scope.userId= "kk";
    $scope.password= "password";
    
    $scope.login = function(){
        $http.defaults.headers.post['Content-Type'] = 'application/x-www-form-urlencoded;charset=utf-8';
        $http({
            method: 'POST',
            url: 'http://www.appwebcloud2.com/JavaBridge/angularWebService.php',
            data: {
                'userId': $scope.userId,
                'password': $scope.password
            },
            headers: {'Content-Type': 'application/x-www-form-urlencoded'}
            }).success(function (data, status, headers, config) {
                $scope.message = data.message;
                $scope.userIdClass = data.userIdClass;
                $scope.passwordClass = data.passwordClass;
            // handle success things
            }).error(function (data, status, headers, config) {
                $scope.message= "http fail";
                // handle error things
            });
    }
    
});
