CREATE DATABASE  IF NOT EXISTS `interntest` /*!40100 DEFAULT CHARACTER SET utf8 */;
USE `interntest`;
-- MySQL dump 10.13  Distrib 5.7.9, for Win64 (x86_64)
--
-- Host: localhost    Database: interntest
-- ------------------------------------------------------
-- Server version	5.7.10-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `loginattempt`
--

DROP TABLE IF EXISTS `loginattempt`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `loginattempt` (
  `loginAttemptId` int(11) NOT NULL AUTO_INCREMENT,
  `loginAttemptUserId` varchar(20) NOT NULL,
  `loginAttemptDateTime` datetime NOT NULL,
  `loginAttemptLatitude` float(10,6) NOT NULL,
  `loginAttemptLongitude` float(10,6) NOT NULL,
  `loginAttemptSuccessful` tinyint(1) NOT NULL,
  PRIMARY KEY (`loginAttemptId`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `loginattempt`
--

LOCK TABLES `loginattempt` WRITE;
/*!40000 ALTER TABLE `loginattempt` DISABLE KEYS */;
INSERT INTO `loginattempt` VALUES (4,'kk','2016-01-23 07:15:26',53.324448,-8.191398,1),(5,'kk','2016-01-23 20:49:45',53.324467,-8.191460,1),(6,'kk','2016-01-23 20:51:44',53.324482,-8.191512,0),(7,'kk','2016-01-23 20:52:26',53.324482,-8.191512,1),(8,'kk','2016-01-23 21:05:27',53.324467,-8.191465,1),(9,'kk','2016-01-23 21:08:48',53.324451,-8.191407,1),(10,'kk','2016-01-23 21:13:38',53.324440,-8.191372,1),(11,'kk','2016-01-23 21:59:56',53.324451,-8.191404,1),(12,'kk','2016-01-23 22:02:38',53.324448,-8.191398,1);
/*!40000 ALTER TABLE `loginattempt` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user`
--

DROP TABLE IF EXISTS `user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user` (
  `userId` varchar(40) NOT NULL,
  `password` varchar(20) NOT NULL,
  PRIMARY KEY (`userId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user`
--

LOCK TABLES `user` WRITE;
/*!40000 ALTER TABLE `user` DISABLE KEYS */;
INSERT INTO `user` VALUES ('kk','password');
/*!40000 ALTER TABLE `user` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2016-01-24  7:09:28
