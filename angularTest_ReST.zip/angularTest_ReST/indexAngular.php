<?php

?>
<html> 
    <head> 
        <link rel='stylesheet' href='css/common.css' />
        <link rel='stylesheet' href='css/login.css' />
        <link rel='stylesheet' href='./css/spinner.css' />  
        
        <script src="http://ajax.googleapis.com/ajax/libs/angularjs/1.4.8/angular.min.js"></script>
        <script type="text/javascript" src="js/jsAngular.js"></script> 
    </head> 

    <body>
        <div class="content" data-ng-app="angularApp" data-ng-controller="angularController">
            <form class="loginForm">
               <input type='text' name='userId' data-ng-model="userId" class='inputFields'  data-ng-class="userIdClass" placeholder='User id' value='kk'/>
               <br />
               <p data-ng-bind="userId"></p>
               <br />

               <input type='password' name='password' data-ng-model="password" class='inputFields' data-ng-class="passwordClass" placeholder='Password' value='password'/>
               <br />
               <p data-ng-bind="password"></p>
               <br />
               <br />
               <button class='loginButtonsCommon loginButton' data-ng-click="login()" name='postButton'>Login</button>
               <br />
               <br />
               <label class='message' id='messageId' name='messageName'><p data-ng-bind="message"></p></label>   
               
            </form><!-- loginForm -->
        </div><!-- content -->
        <div class="spinnerPanel" id="spinnerPanel_id">                 
            <div class="spinnerPanel_inset">
                <div class="spinner bar">
                    <div></div>
                    <div></div>
                    <div></div>
                    <div></div>
                    <div></div>
                    <div></div>
                    <div></div>
                    <div></div>
                </div>
            </div>
        </div>
    </body>
</html>