<?php

    class DBConnection extends Singleton {
        private $dbHost;
        private $dbName;
        private $dbUser;
        private $dbPassword;
        private static $connection;
        private $errorMessage;

        protected function __construct() {
            $this->dbHost = "localhost";
            $this->dbName = "interntest";
            $this->dbUser = "internuser";
            $this->dbPassword = "internpassword";
            $this->errorMessage = null;
            $this->connect();
        }

        private function connect() {

            if(!isset($this->connection)) {
                 try {
                    $this->connection = new PDO("mysql:host=".$this->dbHost.";dbname=".$this->dbName, $this->dbUser, $this->dbPassword);
                    // set the PDO error mode to exception
                    $this->connection->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
                } catch(PDOException $e) {
                    $this->errorMessage = "Database Connection failed: " . $e->getMessage();
                    error_log($e->getMessage(), 0);
                    $this->connection = null;
                }
            }   
            return $this->connection;
        }

        public function isConnected() {
            $result = true;
            if ($this->connection === null) $result = false;
            return $result;
        }

        public function getConnection()
        {
            return $this->connection;
        }

        public function setErrorMessage($message)
        {
            $this->errorMessage = $message;
        }
        
        public function getErrorMessage()
        {
            return $this->errorMessage;
        }
        
        public function closeConnection()
        {
            $this->connection = null;
        }
    }

?>