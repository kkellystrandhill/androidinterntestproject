<?php
    try {
        session_start();
        
        class ReturnedData {
            public $userIdClass = "";
            public $passwordClass = "";
            public $message = "";
        }

        $returnedData = new ReturnedData();
        
        $data                               = file_get_contents('php://input');
        $dataJsonDecode                     = json_decode($data);
        
        $_SESSION['userId']                  = $dataJsonDecode->userId;
        $_SESSION['password']                = $dataJsonDecode->password;       
        session_write_close();
        
        if(isset($_SESSION['userId'])) {
            $userId = isset($_SESSION['userId']) ? $_SESSION['userId'] : "";
            if($userId === ""){
                $returnedData->userIdClass = setClassError();
            } else {
                $returnedData->userIdClass = setClassNormal();
            }
            $password = isset($_SESSION['password']) ? $_SESSION['password'] : "";
            if($password === ""){
                $returnedData->passwordClass = setClassError();
            } else {
                $returnedData->passwordClass = setClassNormal();
            }
            if ($userIdClass === 'inputError' || $passwordClass  === 'inputError') {
                $returnedData->message = 'Invalid login';
            } else {
                $returnedData->message = databaseAccess($userId, $password, 0, 0);
                if ($returnedData->message === "") {  
                    $returnedData->message = 'login successfull:';
                } else {
                    $returnedData->userIdClass = setClassError();
                    $returnedData->passwordClass = setClassError();
                }
            }

        } else {
            $returnedData->userIdClass = setClassNormal();
            $returnedData->passwordClass = setClassNormal();
        }
        
        echo json_encode($returnedData);
        
    } catch(Exception $e) {
        $returnedData->message = "Unexpected error: " . $e->getMessage();
        error_log($e->getMessage(), 0);
        echo json_encode($returnedData);
    }
    
    function __autoload($class_name) {
        require_once 'classes/' . $class_name . '.php';
    }    
    function setClassError() {
        return "inputError";
    }
    function setClassNormal() {
        return "inputNormal";
    }
    function databaseAccess($userId, $password, $loginAttemptLatitude, $loginAttemptlongitude) {
        try {
            $message = '';
            $connection = DBConnection::getInstance();
            if ($connection->isConnected()) {
                $user = new User($userId, $password);
                $user = $user->getRecord();
                if (isset($user)) {  
                    $connectionAttemptSuccessfull = 1;               
                } else {
                    $connectionAttemptSuccessfull = 0;
                    $message = $connection->getErrorMessage();
                }
                $loginAttempt = new LoginAttempt(null, $userId, date("Y-m-d H:i:s"), $loginAttemptLatitude, $loginAttemptlongitude, $connectionAttemptSuccessfull);
                $loginAttempt = $loginAttempt->createRecord();  
                if ($loginAttempt != null && $connectionAttemptSuccessfull === 1) {
                    //header("Location: locationDisplay.html?latitude=" . $loginAttemptLatitude . "&longitude=" . $loginAttemptlongitude);
                }
            } else {
                $message = $connection->getErrorMessage();
            }
            $connection->closeConnection();
        } catch(Exception $e) {
            $message = "Unexpected error: " . $e->getMessage();
            error_log($e->getMessage(), 0);
        }
        return $message;
    }
?>
