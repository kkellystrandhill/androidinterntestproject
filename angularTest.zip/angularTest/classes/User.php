<?php

    class User {
        private	$userId;
        private	$password;
    
        public function	__construct($userId, $password) {
            switch(func_num_args()) {
                case 0 :
                    $this->__constructorDefault();
                    break;
                case 2 :
                    $this->__constructorAllFields($userId, $password);
                    break;
            }
	}
        
        private function __constructorDefault() {
            $this->userId = null;
            $this->password = null;
        }
        
        private function __constructorAllFields($userId, $password) {
            $this->userId = $userId;
            $this->password = $password;
        }
        
        public function	getUserId() {
            return $this->userId;
        }

        public function	setUserId($userId) {
            $this->userId = $userId;
        }

        public function	getPassword() {
            return $this->password;
        }

        public function	setPassword($password) {
            $this->password = $password;
        }
        
        public function getRecord() {
 
            try {
                $connection = DBConnection::getInstance();
                $preparedStatement = $connection->getConnection()->prepare("select * from user where userId = :userId AND password = :password");
                $preparedStatement->bindParam(':userId', $this->userId);
                $preparedStatement->bindParam(':password', $this->password);

                $preparedStatement->execute();
                $rows = $preparedStatement->fetchAll(PDO::FETCH_ASSOC);
                if (sizeof($rows) === 0) {
                    $connection->setErrorMessage("Failed login attempt");
                    return null;
                } else {
                    foreach ($rows as $row) {
                        $this->setUserId($row['userId']);
                        $this->setPassword($row['password']);                                
                    } 
                }
            } catch (PDOException $e) {
                $connection->setErrorMessage($e);
                error_log($e->getMessage(), 0);
            }
            return $this;
        }
    } 
?>