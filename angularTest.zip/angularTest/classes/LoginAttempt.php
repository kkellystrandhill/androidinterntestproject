<?php

    class LoginAttempt {
        private	$loginAttemptId;
        private	$loginAttemptUserId;
        private	$loginAttemptDateTime;
        private	$loginAttemptLatitude;
        private	$loginAttemptlongitude;
        private	$loginAttemptSuccessful;
    
        public function	__construct($loginAttemptId, $loginAttemptUserId, $loginAttemptDateTime, $loginAttemptLatitude, $loginAttemptlongitude, $loginAttemptSuccessful) {
            switch(func_num_args()) {
                case 0 :
                    $this->__constructorDefault();
                    break;
                case 6 :
                    $this->__constructorAllFields($loginAttemptId, $loginAttemptUserId, $loginAttemptDateTime, $loginAttemptLatitude, $loginAttemptlongitude, $loginAttemptSuccessful);
                    break;
            }
	}
        
        private function __constructorDefault() {
            $this->loginAttemptId = null;
            $this->loginAttemptUserId = null; 
            $this->loginAttemptDateTime = null;
            $this->loginAttemptLatitude = null;
            $this->loginAttemptlongitude = null;
            $this->loginAttemptSuccessful = null;
        }
        
        private function __constructorAllFields($loginAttemptId, $loginAttemptUserId, $loginAttemptDateTime, $loginAttemptLatitude, $loginAttemptlongitude, $loginAttemptSuccessful) {
            $this->loginAttemptId = $loginAttemptId;
            $this->loginAttemptUserId = $loginAttemptUserId;
            $this->loginAttemptDateTime = $loginAttemptDateTime;
            $this->loginAttemptLatitude = $loginAttemptLatitude;
            $this->loginAttemptlongitude = $loginAttemptlongitude;
            $this->loginAttemptSuccessful = $loginAttemptSuccessful;
        }
        
        public function	getLoginAttemptId() {
            return $this->$loginAttemptId;
        }

        public function	setLoginAttemptId($loginAttemptId) {
            $this->loginAttemptId = $loginAttemptId;
        }
        
        public function	getLogginAttemptUserId() {
            return $this->$loginAttemptUserId;
        }

        public function	setLogginAttemptUserId($loginAttemptUserId) {
            $this->loginAttemptUserId = $loginAttemptUserId;
        }
        
        public function	getLoginAttemptDateTime() {
            return $this->$loginAttemptDateTime;
        }

        public function	setLoginAttemptDateTime($loginAttemptDateTime) {
            $this->loginAttemptDateTime = $loginAttemptDateTime;
        }
        
        public function	getLogginAttemptLatitude() {
            return $this->$loginAttemptLatitude;
        }

        public function	setLogginAttemptLatitude($loginAttemptLatitude) {
            $this->loginAttemptLatitude = $loginAttemptLatitude;
        }
                
        public function	getLogginAttemptlongitude() {
            return $this->$loginAttemptlongitude;
        }

        public function	setLogginAttemptlongitude($loginAttemptlongitude) {
            $this->loginAttemptlongitude = $loginAttemptlongitude;
        }
        
        public function	getLogginAttemptSuccessful() {
            return $this->$loginAttemptSuccessful;
        }

        public function	setLogginAttemptSuccessful($loginAttemptSuccessful) {
            $this->loginAttemptSuccessful = $loginAttemptSuccessful;
        }
        
        public function createRecord() {
 
            try {
                $connection = DBConnection::getInstance();
                $preparedStatement = $connection->getConnection()->prepare("insert into loginattempt (loginAttemptId, loginAttemptUserId, loginAttemptDateTime, loginAttemptLatitude, loginAttemptlongitude, loginAttemptSuccessful) values (null, :loginAttemptUserId, :loginAttemptDateTime, :loginAttemptLatitude, :loginAttemptlongitude, :loginAttemptSuccessful)");
                $preparedStatement->bindParam(':loginAttemptUserId', $this->loginAttemptUserId);
                $preparedStatement->bindParam(':loginAttemptDateTime', $this->loginAttemptDateTime);
                $preparedStatement->bindParam(':loginAttemptLatitude', $this->loginAttemptLatitude);
                $preparedStatement->bindParam(':loginAttemptlongitude', $this->loginAttemptlongitude);
                $preparedStatement->bindParam(':loginAttemptSuccessful', $this->loginAttemptSuccessful);

                $connection->getConnection()->beginTransaction ();

                if ($preparedStatement->execute()) {
                    $connection->getConnection()->commit();
                } else {
                    $connection->getConnection()->rollback ();
                    $connection->setErrorMessage("Create login attempt record failed");
                }                                
            } catch (PDOException $e) {
                $connection->setErrorMessage($e);
                error_log($e->getMessage(), 0);
                return null;
            }
            return $this;
        }
    } 
?>