var angularTestApp = angular.module('angularApp', []);
angularTestApp.controller('angularController', function($scope) {
    $scope.userId= "kk";
    $scope.password= "password";
});
