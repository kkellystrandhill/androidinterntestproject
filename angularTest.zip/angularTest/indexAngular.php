<?php
    try {
        session_start();
        $message = '';        

        if (isset($_POST["postButton"])) {
            $accepted = array('postButton', 'userId', 'password', 'messageName', 'loginAttemptLatitude', 'loginAttemptlongitude');

            foreach ( $accepted as $name ) {
                if ( isset( $_POST[$name] ) ) {
                    $_SESSION[$name] = $_POST[$name];
                }
            }
            session_write_close();
            header("Location: " . $_SERVER['REQUEST_URI']);
            exit();
        }

        if(isset($_SESSION['postButton'])) {
            $userId = isset($_SESSION['userId']) ? $_SESSION['userId'] : "";
            if($userId === ""){
                $userIdClass = setClassError();
            } else {
                $userIdClass = setClassNormal();
            }
            $password = isset($_SESSION['password']) ? $_SESSION['password'] : "";
            if($password === ""){
                $passwordClass = setClassError();
            } else {
                $passwordClass = setClassNormal();
            }
            if ($userIdClass === 'inputError' || $passwordClass  === 'inputError') {
                $message = 'Invalid login';
            } else {
                $loginAttemptLatitude = isset($_SESSION['loginAttemptLatitude']) ? $_SESSION['loginAttemptLatitude'] : "0000.000000";
                $loginAttemptlongitude = isset($_SESSION['loginAttemptlongitude']) ? $_SESSION['loginAttemptlongitude'] : "0000.000000";
                $message = databaseAccess($userId, $password, $loginAttemptLatitude, $loginAttemptlongitude);
                if ($message === "") {  
                    $message = 'login successfull:';
                } else {
                    $userIdClass = setClassError();
                    $passwordClass = setClassError();
                }
            }
            $_SESSION = array();
        } else {
            $userIdClass = setClassNormal();
            $passwordClass = setClassNormal();
        }
    } catch(Exception $e) {
        $message = "Unexpected error: " . $e->getMessage();
        error_log($e->getMessage(), 0);
    }
    
    function __autoload($class_name) {
        require_once 'classes/' . $class_name . '.php';
    }    
    function setClassError() {
        return "inputError";
    }
    function setClassNormal() {
        return "inputNormal";
    }
    function databaseAccess($userId, $password, $loginAttemptLatitude, $loginAttemptlongitude) { 
        try {
            $message = '';
            $connection = DBConnection::getInstance();
            if ($connection->isConnected()) {
                $user = new User($userId, $password);
                $user = $user->getRecord();
                if (isset($user)) {  
                    $connectionAttemptSuccessfull = 1;               
                } else {
                    $connectionAttemptSuccessfull = 0;
                    $message = $connection->getErrorMessage();
                }
                $loginAttempt = new LoginAttempt(null, $userId, date("Y-m-d H:i:s"), $loginAttemptLatitude, $loginAttemptlongitude, $connectionAttemptSuccessfull);
                $loginAttempt = $loginAttempt->createRecord();  
                if ($loginAttempt != null && $connectionAttemptSuccessfull === 1) {
                    //header("Location: locationDisplay.html?latitude=" . $loginAttemptLatitude . "&longitude=" . $loginAttemptlongitude);
                }
            } else {
                $message = $connection->getErrorMessage();
            }
            $connection->closeConnection();
        } catch(Exception $e) {
            $message = "Unexpected error: " . $e->getMessage();
            error_log($e->getMessage(), 0);
        }
        return $message;
    }
?>
<html> 
    <head> 
        <link rel='stylesheet' href='css/common.css' />
        <link rel='stylesheet' href='css/login.css' />
        
        <script src="http://ajax.googleapis.com/ajax/libs/angularjs/1.4.8/angular.min.js"></script>
        <script type="text/javascript" src="js/jsAngular.js"></script> 
    </head> 

    <body>
        <div class="content" data-ng-app="angularApp" data-ng-controller="angularController">
            <form class="loginForm" method='post' action='indexAngular.php'>
               <input type='text' name='userId' data-ng-model="userId" class='inputFields  <?php echo $userIdClass; ?>' placeholder='User id' value='<?php echo $userId; ?>'/>
               <br />
               <p data-ng-bind="userId"></p>
               <br />

               <input type='password' name='password' data-ng-model="password" class='inputFields  <?php echo $passwordClass; ?>' placeholder='Password' value='<?php echo $password; ?>'/>
               <br />
               <p data-ng-bind="password"></p>
               <br />
               <br />
               <input class='loginButtonsCommon loginButton' type='submit' value='Login' name='postButton'/>
               <br />
               <br />
               <label class='message' id='messageId' name='messageName'><?php echo $message; ?></label>   
               <input id='loginAttemptLatitudeId' type="hidden" name="loginAttemptLatitude"/>
               <input id='loginAttemptlongitude' type="hidden" name="loginAttemptlongitude"/>
            </form><!-- loginForm -->
        </div><!-- content -->
    </body>
</html>